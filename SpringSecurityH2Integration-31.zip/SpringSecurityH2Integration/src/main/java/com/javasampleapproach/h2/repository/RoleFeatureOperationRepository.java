package com.javasampleapproach.h2.repository;

import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;

import com.javasampleapproach.h2.model.RoleFeatureOperation;

public interface RoleFeatureOperationRepository extends JpaRepository<RoleFeatureOperation, Long> {

	Set<RoleFeatureOperation> findByFeature(final String feature);

}
