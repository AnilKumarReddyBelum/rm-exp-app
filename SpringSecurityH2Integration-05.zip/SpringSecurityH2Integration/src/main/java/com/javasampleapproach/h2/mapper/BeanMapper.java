package com.javasampleapproach.h2.mapper;

import org.springframework.stereotype.Component;

import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.ConfigurableMapper;

@Component
public class BeanMapper extends ConfigurableMapper {

	@Override
	protected void configure(MapperFactory factory) {
		factory.classMap(Bean.class, BeanDTO.class).field("name", "name").field("address", "address").byDefault()
				.register();
	}

}
