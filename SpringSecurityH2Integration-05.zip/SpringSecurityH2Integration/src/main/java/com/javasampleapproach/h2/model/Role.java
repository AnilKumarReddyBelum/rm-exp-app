package com.javasampleapproach.h2.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.security.core.GrantedAuthority;

@Entity
public class Role implements GrantedAuthority {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Column(name = "role_name")
	private String role;

	@RestResource(exported = false)
	@ManyToMany(cascade = { CascadeType.PERSIST, CascadeType.MERGE }, fetch = FetchType.LAZY)
	@JoinTable(name = "role_res", joinColumns = @JoinColumn(name = "roleId"), inverseJoinColumns = @JoinColumn(name = "featureoptionId"))
	private Set<RoleFeatureOperation> featureOperations;

	public Role() {

	}

	public Long getId() {
		return id;
	}

	public Set<RoleFeatureOperation> getFeatureOperations() {
		return featureOperations;
	}

	public void setFeatureOperations(Set<RoleFeatureOperation> featureOperations) {
		this.featureOperations = featureOperations;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String getAuthority() {
		return getRole();
	}

}
