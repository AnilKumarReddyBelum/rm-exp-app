package com.javasampleapproach.h2.repository;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javasampleapproach.h2.mapper.UserMapper;
import com.javasampleapproach.h2.model.User;
import com.javasampleapproach.h2.model.UserDTO;

@Service
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private UserDTORepository userDTORepository;

	@Autowired
	private UserMapper mapper;

	@Override
	@Transactional
	public UserDTO closeUser(final String userName) {
		User user = userRepository.findByUserName(userName);
		System.out.println("user=>"+user.getUserName() +" "+user.getRoles());
		UserDTO userDTO = mapper.map(user, UserDTO.class);
		
		System.out.println("deleting from the table user");
		userRepository.delete(user);
		
		System.out.println("insert into the table user");
		UserDTO userDTO2 = userDTORepository.save(userDTO);
		System.out.println("userDTO2=>"+userDTO2.getUserName() +" "+userDTO2.getRoles());
		return userDTO2;
	}

}
