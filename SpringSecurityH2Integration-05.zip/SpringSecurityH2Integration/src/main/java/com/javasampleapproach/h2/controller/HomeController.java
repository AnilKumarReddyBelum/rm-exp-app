package com.javasampleapproach.h2.controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.javasampleapproach.h2.mapper.Bean;
import com.javasampleapproach.h2.mapper.BeanDTO;
import com.javasampleapproach.h2.mapper.BeanMapper;
import com.javasampleapproach.h2.mapper.UserMapper;
import com.javasampleapproach.h2.model.Role;
import com.javasampleapproach.h2.model.RoleFeatureOperation;
import com.javasampleapproach.h2.model.User;
import com.javasampleapproach.h2.model.UserDTO;
import com.javasampleapproach.h2.repository.RoleFeatureOperationRepository;
import com.javasampleapproach.h2.repository.RoleRepository;
import com.javasampleapproach.h2.repository.UserRepository;
import com.javasampleapproach.h2.repository.UserService;

@RestController
public class HomeController {

	@Autowired
	private RoleFeatureOperationRepository featureOperationRepository;

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private BeanMapper beanMapper;

	@Autowired
	private UserMapper userMapper;

	@Autowired
	private UserService userService;

	@PreAuthorize("hasRole('ADMIN') || hasRole('APPROVER')")
	@GetMapping("/getAllUsersInfo")
	public List<User> getAllUsersInfo() {
		return userRepository.findAll();
	}

	@GetMapping("/save/saveUser")
	public String saveUser() {
		List<User> list = new ArrayList<>();
		Role role = roleRepository.findByRole("ADMIN");
		Set<Role> roles = new HashSet<>();
		roles.add(role);
		User user = new User("anil", "anil", true);
		user.setRoles(roles);
		list.add(user);

		Role role2 = roleRepository.findByRole("APPROVER");
		Set<Role> roles2 = new HashSet<>();
		roles2.add(role2);
		User user2 = new User("Alok", "Alok", true);
		user2.setRoles(roles2);
		list.add(user2);
		
		Role role3 = roleRepository.findByRole("APPROVER");
		Set<Role> roles3 = new HashSet<>();
		roles3.add(role3);
		User user3 = new User("abhi", "abhi", true);
		user3.setRoles(roles3);
		list.add(user3);
		
		Role role4 = roleRepository.findByRole("ADMIN");
		Set<Role> roles4 = new HashSet<>();
		roles4.add(role4);
		User user4 = new User("seenu", "seenu", true);
		user4.setRoles(roles4);
		list.add(user4);

		userRepository.save(list);
		return "success";
	}

	@GetMapping("/save/saveRoleOperationFeature")
	public String saveRoleOperationFeature() {
		RoleFeatureOperation featureOperation1 = new RoleFeatureOperation(null, "USER_SIGNUP", "VIEW");
		RoleFeatureOperation featureOperation2 = new RoleFeatureOperation(null, "USER_SIGNUP", "APPROVE");
		List<RoleFeatureOperation> list = new ArrayList<>();
		list.add(featureOperation1);
		list.add(featureOperation2);
		featureOperationRepository.save(list);
		return "success";
	}

	@GetMapping("/save/saveRole")
	public String saveRole() {

		List<Role> list = new ArrayList<>();

		// *******************ADMIN
		Role role = new Role();
		role.setRole("ADMIN");
		Set<RoleFeatureOperation> featureOperations = new HashSet<>();
		for (RoleFeatureOperation featureOperation : featureOperationRepository.findByFeature("USER_SIGNUP")) {
			if (featureOperation.getOperation() != null && featureOperation.getOperation().equalsIgnoreCase("VIEW")) {
				featureOperations.add(featureOperation);
			}
		}
		role.setFeatureOperations(featureOperations);
		list.add(role);

		// ********************APPROVER
		Role role2 = new Role();
		role2.setRole("APPROVER");
		Set<RoleFeatureOperation> featureOperations2 = new HashSet<>();
		for (RoleFeatureOperation featureOperation : featureOperationRepository.findByFeature("USER_SIGNUP")) {
			if (featureOperation.getOperation() != null && (featureOperation.getOperation().equalsIgnoreCase("VIEW")
					|| featureOperation.getOperation().equalsIgnoreCase("APPROVE"))) {
				featureOperations2.add(featureOperation);
			}
		}
		role2.setFeatureOperations(featureOperations2);
		list.add(role2);

		roleRepository.save(list);

		return "success";
	}

	@GetMapping("/save/saveAll")
	public String saveAll() {
		final String uri1 = "http://localhost:8080/save/saveRoleOperationFeature";
		final String uri2 = "http://localhost:8080/save/saveRole";
		final String uri3 = "http://localhost:8080/save/saveUser";

		RestTemplate restTemplate = new RestTemplate();
		String result1 = restTemplate.getForObject(uri1, String.class);
		String result2 = restTemplate.getForObject(uri2, String.class);
		String result3 = restTemplate.getForObject(uri3, String.class);

		System.out.println(result1);
		System.out.println(result2);
		System.out.println(result3);

		return new StringBuilder().append(result1).append(result2).append(result3).toString();
	}

	@PreAuthorize("isAdminCanViewUserSignUp(#httpServletRequest)")
	@RequestMapping(method = RequestMethod.GET, value = "/isAdminCanViewUserSignUp/{id}")
	public User adminCanView(@PathVariable long id, HttpServletRequest httpServletRequest) {
		return userRepository.findOne(id);
	}

	@PreAuthorize("isApproverCanViewAndApproveUserSignUp(#httpServletRequest)")
	@RequestMapping(method = RequestMethod.GET, value = "/isApproverCanViewAndApproveUserSignUp/{id}")
	public User approverCanView(@PathVariable long id, HttpServletRequest httpServletRequest) {
		return userRepository.findOne(id);
	}

	@GetMapping("/secure")
	public String secureResource() {
		return "Secure-Resource";
	}

	@GetMapping("/testOrrika")
	public BeanDTO testOrrika() {
		Bean bean = new Bean("Anil", "HYD");
		BeanDTO beanDTO = beanMapper.map(bean, BeanDTO.class);
		return beanDTO;
	}

	@GetMapping("/mapUserToUserDTO/{userName}")
	public UserDTO mapUserToUserDTO(@PathVariable String userName) {
		System.out.println("*******************************");
		System.out.println("userName==>"+userName);
		return userService.closeUser(userName);
	}

}
