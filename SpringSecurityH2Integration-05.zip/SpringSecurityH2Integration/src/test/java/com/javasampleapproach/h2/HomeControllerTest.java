package com.javasampleapproach.h2;

import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.javasampleapproach.h2.controller.HomeController;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { HomeController.class, SpringSecurityH2IntegrationApplication.class })
@TestPropertySource(locations = { "classpath:commonTestData.properties" })
@TestExecutionListeners(inheritListeners = false, listeners = { DependencyInjectionTestExecutionListener.class,
		DirtiesContextTestExecutionListener.class })
public class HomeControllerTest {

	@Autowired
	private WebApplicationContext webApplicationContext;

	private MockMvc mockMvc;

	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.webApplicationContext).build();
	}

	@Test
	public void secureResourceTest() throws Exception {
		MvcResult actions = mockMvc.perform(get("/secure")).andExpect(status().isOk()).andDo(print()).andReturn();
		String content = actions.getResponse().getContentAsString();
		assertNotNull(content);
		System.out.println("secureResourceTest :: content: " + content);
	}

	@Test
	public void saveAllTest() throws Exception {
		MvcResult actions = mockMvc.perform(get("/save/saveAll")).andExpect(status().isOk()).andDo(print()).andReturn();
		String content = actions.getResponse().getContentAsString();
		assertNotNull(content);
		System.out.println("secureResourceTest :: content: " + content);
	}

	@Test
	public void getAllUsersInfoTest() throws Exception {
		Authentication auth = new UsernamePasswordAuthenticationToken("anil", "anil");
		SecurityContext securityContext = SecurityContextHolder.getContext();
		securityContext.setAuthentication(auth);
		MvcResult actions2 = mockMvc.perform(get("/getAllUsersInfo")).andExpect(status().isOk()).andDo(print())
				.andReturn();
		String content2 = actions2.getResponse().getContentAsString();
		assertNotNull(content2);
		System.out.println("secureResourceTest :: content: " + content2);

	}
}
