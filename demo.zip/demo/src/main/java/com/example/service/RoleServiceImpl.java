package com.example.service;

import java.util.Collection;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.domain.Role;
import com.example.repository.RoleRepository;

@Service
@Transactional
public class RoleServiceImpl implements RoleService {

	@Autowired
	RoleRepository roleRepository;

	@Override
	public Role addRole(Role role) {
		return roleRepository.save(role);
	}

	@Override
	public Role updateRole(Role role) {
		return roleRepository.save(role);
	}

	@Override
	public void removeRole(Long id) {
		roleRepository.deleteById(id);
	}

	@Override
	public Collection<Role> findAllRoles() {
		return roleRepository.findAll();
	}

	@Override
	public Optional<Role> findRole(Long id) {
		return roleRepository.findById(id);
	}

}
