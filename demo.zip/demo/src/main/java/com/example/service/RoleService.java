package com.example.service;

import java.util.Collection;
import java.util.Optional;

import com.example.domain.Role;

public interface RoleService {

	Role addRole(Role role);

	Role updateRole(Role role);

	void removeRole(Long id);

	Collection<Role> findAllRoles();

	Optional<Role> findRole(Long id);

}
