package com.example.service;

import java.util.Collection;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.domain.User;
import com.example.repository.UserRepository;

@Service
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepository repository;

	@Override
	public User addUser(User user) {
		return repository.save(user);
	}

	@Override
	public User updateUser(User user) {
		return repository.save(user);
	}

	@Override
	public void removeUser(Long id) {
		repository.deleteById(id);
	}

	@Override
	public Optional<User> findUserById(Long id) {
		return repository.findById(id);
	}

	@Override
	public Collection<User> findAllUsers() {
		return repository.findAll();
	}

}
