package com.example.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.domain.Role;
import com.example.domain.User;
import com.example.service.RoleService;
import com.example.service.UserService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("users")
@Slf4j
public class UserController {

	@Autowired
	UserService userService;

	@Autowired
	RoleService roleService;

	@PostMapping
	User addUser(@RequestBody User user) {
		return userService.addUser(user);
	}

	@PutMapping
	User updateUser(@RequestBody User user) {
		return userService.updateUser(user);
	}

	@DeleteMapping("/{id}")
	void removeUser(@PathVariable("id") Long id) {
		userService.removeUser(id);
	}

	@GetMapping("/{id}")
	User findUserById(@PathVariable("id") Long id) {
		return userService.findUserById(id).get();
	}

	@GetMapping
	Collection<User> findAllUsers() {
		return userService.findAllUsers();
	}

	@PatchMapping("/{uid}/assignRole/{rid}")
	void assignRole(@PathVariable("uid") Long uid, @PathVariable("rid") Long rid) throws Exception {
		User user = userService.findUserById(uid).orElseThrow(Exception::new);
		Role role = roleService.findRole(rid).orElseThrow(Exception::new);
		if (user.getRoles() != null && user.getRoles().stream().filter(r -> r.getId().equals(rid)).count() == 1) {
			log.error("Already User has been assigned to this role!");
		} else {
			user.getRoles().add(role);
			userService.updateUser(user);
			log.debug("User has been successfully assigned to this given role!");
		}

	}

}
