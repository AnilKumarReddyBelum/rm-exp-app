package com.example.domain;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "role_feature_operation")
@Data
public class RoleFeatureOperation {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", unique = true, nullable = false)
	private Long id;

	@Column(name = "feature")
	private String feature;

	@Column(name = "operation")
	private String operation;

	public RoleFeatureOperation() {

	}

	public RoleFeatureOperation(Long id, String feature, String operation) {
		super();
		this.id = id;
		this.feature = feature;
		this.operation = operation;
	}

}
