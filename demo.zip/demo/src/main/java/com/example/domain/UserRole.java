package com.example.domain;
import lombok.Data;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity
@Table(name = "user_role")
@IdClass(MyKey.class)
@Data
public class UserRole {

    @Id
    private Long userId;

    @Id
    private Long roleId;

    public UserRole() {
    }

    public UserRole(Long userId, Long roleId) {
        this.userId = userId;
        this.roleId = roleId;
    }

}

 class MyKey implements Serializable {
    private Long userId;
    private Long roleId;
}