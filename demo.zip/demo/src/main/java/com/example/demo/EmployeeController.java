package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import net.sf.ehcache.CacheManager;

@RestController
public class EmployeeController {

	@Autowired
	EmployeeRepository employeeRepository;

	@GetMapping("/save")
	Employee save() {
		return employeeRepository.save(new Employee(null, "Anil", 7900.00));
	}

	@GetMapping("/get/{id}")
	Employee get(@PathVariable(name = "id") final Long id) {
		return employeeRepository.findById(id).get();
	}

	@GetMapping("/getAll")
	List<Employee> getAll() {
		return employeeRepository.findAll();
	}

	@GetMapping("/getCacheSize")
	int getCacheSize() {
		int size = CacheManager.ALL_CACHE_MANAGERS.get(0).getCache("com.example.demo.Employee").getSize();
		return size;
	}

}
