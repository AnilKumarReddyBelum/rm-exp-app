package com.bapoc.controller.bapoceureka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class BapocEurekaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BapocEurekaApplication.class, args);
	}
}
