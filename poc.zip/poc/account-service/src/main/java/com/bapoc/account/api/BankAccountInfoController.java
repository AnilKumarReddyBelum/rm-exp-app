package com.bapoc.account.api;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bapoc.account.model.AccountInformation;

@RestController
public class BankAccountInfoController {

	protected Logger logger = Logger.getLogger(BankAccountInfoController.class.getName());

	private List<AccountInformation> accountInformations;

	public BankAccountInfoController() {
		accountInformations = new ArrayList<AccountInformation>();
		accountInformations.add(new AccountInformation(new BigInteger("234643846"), "anil", "kumar", "Hyd"));
		accountInformations.add(new AccountInformation(new BigInteger("234643847"), "reddy", "kumar", "Hyd"));
		accountInformations.add(new AccountInformation(new BigInteger("234643848"), "belum", "kumar", "Hyd"));
	}

	@RequestMapping("/bank/account/{number}")
	public AccountInformation findByNumber(@PathVariable("number") String number) {
		return accountInformations.stream().filter(it -> it.getAccountNumber().equals(number)).findFirst().get();
	}

	@RequestMapping("/bank/accounts")
	public List<AccountInformation> accounts() {
		return accountInformations;
	}

}
