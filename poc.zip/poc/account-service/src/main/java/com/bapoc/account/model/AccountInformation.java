package com.bapoc.account.model;

import java.io.Serializable;
import java.math.BigInteger;

public class AccountInformation implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private BigInteger accountNumber;
	private String fname;
	private String lname;
	private String address;

	public AccountInformation(BigInteger accountNumber, String fname, String lname, String address) {
		super();
		this.accountNumber = accountNumber;
		this.fname = fname;
		this.lname = lname;
		this.address = address;
	}

	public BigInteger getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(BigInteger accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

}
