package com.javasampleapproach.h2.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.javasampleapproach.h2.model.RoleResponsibility;

public interface RoleResponsibilityRepository extends JpaRepository<RoleResponsibility, Long> {

}
