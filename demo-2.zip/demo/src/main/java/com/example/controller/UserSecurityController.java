package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.domain.PasswordChangeRequest;
import com.example.service.UserSecurityService;

@RestController
@RequestMapping("securitymanager")
public class UserSecurityController {

	@Autowired
	UserSecurityService userSecurityService;

	@PostMapping("/reset")
	PasswordChangeRequest resetPassword(@RequestBody PasswordChangeRequest passwordChangeRequest) {
		return userSecurityService.resetPassword(passwordChangeRequest);
	}

	@PostMapping("/forgot")
	PasswordChangeRequest forgotPassword(@RequestBody PasswordChangeRequest passwordChangeRequest) {
		return userSecurityService.forgotPassword(passwordChangeRequest);
	}

}
