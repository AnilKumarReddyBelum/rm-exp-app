package com.example.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.domain.Role;
import com.example.service.RoleService;

@RestController
@RequestMapping("roles")
public class RoleController {

	@Autowired
	RoleService roleService;

	@PostMapping
	Role addRole(@RequestBody Role role) {
		return roleService.addRole(role);
	}

	@PostMapping("/addRoles")
	Collection<Role> addRoles(@RequestBody Collection<Role> roles) {
		return roleService.addRoles(roles);
	}

	@PutMapping
	Role updateRole(@RequestBody Role role) {
		return roleService.updateRole(role);
	}

	@DeleteMapping("/{id}")
	void removeRole(@PathVariable("id") Long id) {
		roleService.removeRole(id);
	}

	@GetMapping
	Collection<Role> findAllRoles() {
		return roleService.findAllRoles();
	}

	@GetMapping("/{id}")
	Role findRole(@PathVariable("id") Long id) throws Exception {
		return roleService.findRole(id).get();
	}

}
