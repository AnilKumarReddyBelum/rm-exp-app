package com.example.service;

import java.util.Collection;
import java.util.Optional;

import com.example.domain.User;

public interface UserService {

	User addUser(User user);

	User updateUser(User user);

	void removeUser(Long id);

	Optional<User> findUserById(Long id);
	
	Collection<User> findAllUsers();
}
