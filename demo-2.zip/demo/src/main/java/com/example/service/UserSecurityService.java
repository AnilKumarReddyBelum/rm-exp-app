package com.example.service;

import com.example.domain.PasswordChangeRequest;

public interface UserSecurityService {
	PasswordChangeRequest resetPassword(PasswordChangeRequest passwordChangeRequest);
	PasswordChangeRequest forgotPassword(PasswordChangeRequest passwordChangeRequest);
}
