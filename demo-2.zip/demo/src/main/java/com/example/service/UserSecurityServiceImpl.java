package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.domain.PasswordChangeRequest;
import com.example.repository.UserSecurityRepository;

@Service
@Transactional
public class UserSecurityServiceImpl implements UserSecurityService {

	@Autowired
	UserSecurityRepository userSecurityRepository;

	@Override
	public PasswordChangeRequest resetPassword(PasswordChangeRequest passwordChangeRequest) {
		return userSecurityRepository.save(passwordChangeRequest);
	}

	@Override
	public PasswordChangeRequest forgotPassword(PasswordChangeRequest passwordChangeRequest) {
		return userSecurityRepository.save(passwordChangeRequest);
	}

}
