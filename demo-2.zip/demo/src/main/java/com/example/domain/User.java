package com.example.domain;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "user")
@Data
public class User implements Serializable {

	@Id
	@GeneratedValue
	private Long id;

	private String userName;

	@Column
	private String password;
	private String uid;
	private boolean status;
	private String phone;
	private String nationality;
	private String employeeCode;
	private LocalDate startDate;

	@Column(name = "email_address")
	private String email;

	@Column(name = "first_name")
	private String firstName;

	@Column(name = "last_name")
	private String lastName;

	@Column(name = "contact_email")
	private String contactEmail;

	@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinTable(name = "user_role", joinColumns = @JoinColumn(name = "userId"), inverseJoinColumns = @JoinColumn(name = "roleId"))
	private Set<Role> roles;

	public User() {
	}

	public User(String userName, String password, boolean status) {
		this.userName = userName;
		this.password = password;
		this.status = status;
	}

}
