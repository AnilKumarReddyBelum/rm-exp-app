package com.example.domain;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

import lombok.Data;

@Entity
@Data
public class Role {

	@Id
	@GeneratedValue
	private Long id;

	@Column(name = "role_name")
	private String role;

	@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinTable(name = "role_res", joinColumns = @JoinColumn(name = "role_id"), inverseJoinColumns = @JoinColumn(name = "featureoption_id"))
	private Set<RoleFeatureOperation> featureOperations;

}
