package com.example.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "password_change_request")
@Data
public class PasswordChangeRequest {

	@Id
	@GeneratedValue
	private Long id;

	@Column
	private String type;// FORGOT-PASSWORD or RESET-PASSWORD

	@Column
	private String userName;

	@Column
	private String userEmail;

	@Column
	private String clientMachine;

	@Column
	private String clientIpAddress;

	@Column
	private String clientMacAddress;

	@Column
	private String clientBrowser;

	@Column
	private String emailSent;

	@Column
	private String newPassword;

	@Column
	private Date createdOn;

}
