package com.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.example.domain.PasswordChangeRequest;

public interface UserSecurityRepository
		extends JpaRepository<PasswordChangeRequest, Long>, CrudRepository<PasswordChangeRequest, Long> {

}
