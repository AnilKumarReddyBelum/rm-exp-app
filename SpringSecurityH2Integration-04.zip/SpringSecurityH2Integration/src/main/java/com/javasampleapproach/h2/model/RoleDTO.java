package com.javasampleapproach.h2.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.security.core.GrantedAuthority;

@Entity
@Table(name = "RoleDTO")
public class RoleDTO implements GrantedAuthority {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Column(name = "role_name")
	private String role;

	@RestResource(exported = false)
	@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinTable(name = "role_res_dto", joinColumns = @JoinColumn(name = "roleId"), inverseJoinColumns = @JoinColumn(name = "featureoptionId"))
	private Set<RoleFeatureOperationDTO> featureOperations;

	public RoleDTO() {

	}

	public Long getId() {
		return id;
	}

	public Set<RoleFeatureOperationDTO> getFeatureOperations() {
		return featureOperations;
	}

	public void setFeatureOperations(Set<RoleFeatureOperationDTO> featureOperations) {
		this.featureOperations = featureOperations;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String getAuthority() {
		return getRole();
	}

}
