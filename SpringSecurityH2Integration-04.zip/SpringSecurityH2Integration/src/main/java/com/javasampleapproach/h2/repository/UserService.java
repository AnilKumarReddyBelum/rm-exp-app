package com.javasampleapproach.h2.repository;

import com.javasampleapproach.h2.model.UserDTO;

public interface UserService {

	UserDTO closeUser(Long id);

}
