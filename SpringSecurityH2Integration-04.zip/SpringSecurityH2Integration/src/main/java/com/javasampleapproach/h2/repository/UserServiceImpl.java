package com.javasampleapproach.h2.repository;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javasampleapproach.h2.mapper.UserMapper;
import com.javasampleapproach.h2.model.User;
import com.javasampleapproach.h2.model.UserDTO;

@Service
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private UserDTORepository userDTORepository;

	@Autowired
	private UserMapper mapper;

	@Override
	@Transactional
	public UserDTO closeUser(Long id) {
		User user = userRepository.findOne(id);
		UserDTO userDTO = mapper.map(user, UserDTO.class);
		UserDTO userDTO2 = userDTORepository.save(userDTO);
		userRepository.delete(id);
		return userDTO2;
	}

}
