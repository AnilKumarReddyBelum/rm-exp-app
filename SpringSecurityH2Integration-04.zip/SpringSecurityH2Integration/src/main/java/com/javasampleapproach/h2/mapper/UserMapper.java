package com.javasampleapproach.h2.mapper;

import org.springframework.stereotype.Component;

import com.javasampleapproach.h2.model.User;
import com.javasampleapproach.h2.model.UserDTO;

import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.ConfigurableMapper;

@Component
public class UserMapper extends ConfigurableMapper {

	@Override
	protected void configure(MapperFactory factory) {
		factory.classMap(User.class, UserDTO.class)/*.field("id", "id").field("userName", "userName")
				.field("status", "status").field("password", "password").field("roles", "roles").*/.byDefault().register();
	}

}
