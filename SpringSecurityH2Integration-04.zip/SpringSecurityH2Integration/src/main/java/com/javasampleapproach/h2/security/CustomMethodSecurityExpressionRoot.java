package com.javasampleapproach.h2.security;

import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.access.expression.SecurityExpressionRoot;
import org.springframework.security.access.expression.method.MethodSecurityExpressionOperations;
import org.springframework.security.core.Authentication;

import com.javasampleapproach.h2.model.Role;
import com.javasampleapproach.h2.model.RoleFeatureOperation;
import com.javasampleapproach.h2.model.User;
import com.javasampleapproach.h2.repository.UserRepository;

public class CustomMethodSecurityExpressionRoot extends SecurityExpressionRoot
		implements MethodSecurityExpressionOperations {

	private static Logger logger = LoggerFactory.getLogger(CustomMethodSecurityExpressionRoot.class);

	private UserRepository repository;

	public CustomMethodSecurityExpressionRoot(Authentication authentication, UserRepository repository) {
		super(authentication);
		logger.info("entering constructor");
		this.repository = repository;
		logger.info("exit constructor");
	}

	public boolean isApproverCanViewAndApproveUserSignUp(HttpServletRequest httpServletRequest) {
		logger.info("method entry :: adminCanView with data :: " + httpServletRequest.getUserPrincipal().getName());
		boolean isView = false;
		boolean isApprove = false;
		User user2 = repository.findByUserName(httpServletRequest.getUserPrincipal().getName());
		Set<Role> roles = user2.getRoles();
		for (Role r : roles) {
			if (r.getRole() != null && (r.getRole().equalsIgnoreCase("APPROVER"))) {
				for (RoleFeatureOperation featureOperation : r.getFeatureOperations()) {
					if (featureOperation.getOperation() != null && featureOperation.getFeature() != null
							&& featureOperation.getFeature().equalsIgnoreCase("USER_SIGNUP")) {
						if (featureOperation.getOperation().equalsIgnoreCase("VIEW")) {
							isView = true;
						} else if (featureOperation.getOperation().equalsIgnoreCase("APPROVE")) {
							isApprove = true;
						}
					}
				}
			}
		}
		logger.info("methodExit :: " + (isView && isApprove));
		return (isView && isApprove);
	}

	public boolean isAdminCanViewUserSignUp(HttpServletRequest httpServletRequest) {
		logger.info("method entry :: adminCanView with data :: " + httpServletRequest.getUserPrincipal().getName());
		boolean flag = false;

		User user2 = repository.findByUserName(httpServletRequest.getUserPrincipal().getName());
		Set<Role> roles = user2.getRoles();
		for (Role r : roles) {
			if (r.getRole() != null && (r.getRole().equalsIgnoreCase("ADMIN"))) {
				for (RoleFeatureOperation featureOperation : r.getFeatureOperations()) {
					if (featureOperation.getOperation() != null && featureOperation.getFeature() != null
							&& featureOperation.getFeature().equalsIgnoreCase("USER_SIGNUP")
							&& featureOperation.getOperation().equalsIgnoreCase("VIEW")) {
						flag = true;
					}
				}
			}
		}
		logger.info("methodExit :: " + flag);
		return flag;
	}

	@Override
	public void setFilterObject(Object filterObject) {
		// TODO Auto-generated method stub

	}

	@Override
	public Object getFilterObject() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setReturnObject(Object returnObject) {
		// TODO Auto-generated method stub

	}

	@Override
	public Object getReturnObject() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object getThis() {
		// TODO Auto-generated method stub
		return null;
	}

}
