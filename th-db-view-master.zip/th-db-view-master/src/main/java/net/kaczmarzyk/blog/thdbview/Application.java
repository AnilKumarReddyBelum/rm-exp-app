/**
 * The MIT License (MIT)
 *
 * Copyright (c) 2015 Tomasz Kaczmarzyk
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package net.kaczmarzyk.blog.thdbview;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.thymeleaf.spring4.SpringTemplateEngine;
import org.thymeleaf.spring4.templateresolver.SpringResourceTemplateResolver;
import org.thymeleaf.templateresolver.TemplateResolver;

import com.google.common.collect.Sets;

@Configuration
@ComponentScan
@EnableAutoConfiguration
public class Application {

	@Autowired
	TemplateRepository templateRepo;

	@PostConstruct
	public void initializeSampleData() {

		templateRepo.save(new Template(
				"<!DOCTYPE html> <html lang='en' xmlns:th='http://www.thymeleaf.org' xmlns='http://www.w3.org/1999/xhtml'> <head> <title>Bootstrap Example</title> <meta charset='utf-8'/> <meta name='viewport' content='width=device-width, initial-scale=1'/> <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css'/> <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script> <script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js'></script> <script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js'></script> </head> <body> <div class='container'> <div class='card' style='width:50%'> <div class='card-header'> Dear <strong th:inline=\'text\'>[[${userEmail}]]</strong> <p>Below are the request details.</p> </div> <div class='card-body'> <table class='table table-bordered' style='width:50%'> <tbody> <tr><td>Business Name</td><td><strong th:inline=\'text\'>[[${bn}]]</strong></td></tr> <tr><td>Sub Business Name</td><td><strong th:inline=\'text\'>[[${sbn}]]</strong></td></tr> <tr><td>Role Requested</td><td><strong th:inline=\'text\'>[[${role}]]</strong></td></tr> <tr><td>Approver Email</td><td><strong th:inline=\'text\'>[[${approverEmail}]]</strong></td></tr> <tr><td>Comments</td><td><strong th:inline=\'text\'>[[${comments}]]</strong></td></tr> </tbody> </table> </div> <div class='card-footer'> http://bankingadmin-test.us-east-2.elasticbeanstalk.com/<strong th:inline=\'text\'>[[${comments}]]</strong><br/> You will receive an email once all approvals are obtained.</div> </div> </div> </body> </html>"));
	}

	@Bean
	public TemplateResolver springThymeleafTemplateResolver() {
		SpringResourceTemplateResolver resolver = new SpringResourceTemplateResolver();
		resolver.setPrefix("classpath:/templates/");
		resolver.setSuffix(".html");
		resolver.setOrder(1);
		return resolver;
	}

	@Bean
	public DbTemplateResolver dbTemplateResolver() {
		DbTemplateResolver resolver = new DbTemplateResolver();
		resolver.setOrder(2);
		return resolver;
	}

	@Bean
	public SpringTemplateEngine thymeleafTemplateEngine() {
		SpringTemplateEngine engine = new SpringTemplateEngine();
		engine.setTemplateResolvers(Sets.newHashSet(springThymeleafTemplateResolver(), dbTemplateResolver()));
		return engine;
	}

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}
}
