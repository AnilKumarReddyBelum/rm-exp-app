package com.velocity.stringasemail.velocitystringasemail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VelocityStringasemailApplication {

	public static void main(String[] args) {
		SpringApplication.run(VelocityStringasemailApplication.class, args);
	}
}
