package com.velocity.stringasemail.velocitystringasemail;

public interface VelocityEmailTemplateEngine {

	String makeTemplate(final EmailTemplate emailTemplate, final String sn);

}
