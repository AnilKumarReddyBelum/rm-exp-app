package com.velocity.stringasemail.velocitystringasemail;

import java.io.StringReader;
import java.io.StringWriter;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.runtime.RuntimeServices;
import org.apache.velocity.runtime.RuntimeSingleton;
import org.apache.velocity.runtime.parser.ParseException;
import org.apache.velocity.runtime.parser.node.SimpleNode;
import org.springframework.stereotype.Service;

@Service
public class VelocityEmailTemplateEngineImpl implements VelocityEmailTemplateEngine {

	@Override
	public String makeTemplate(EmailTemplate emailTemplate, String name) {
		RuntimeServices rs = RuntimeSingleton.getRuntimeServices();
		StringReader sr = new StringReader(emailTemplate.getContent());
		SimpleNode sn = null;
		try {
			sn = rs.parse(sr, "User Information");
		} catch (ParseException e) {
			System.out.println(e.getLocalizedMessage());
		}

		Template t = new Template();
		t.setRuntimeServices(rs);
		t.setData(sn);
		t.initDocument();

		VelocityContext vc = new VelocityContext();
		vc.put("username", name);

		StringWriter sw = new StringWriter();
		t.merge(vc, sw);

		System.out.println(sw.toString());

		return sw.toString();
	}

}
